package controller;

import calculation.Calc;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class AppController implements Initializable {

    @FXML
    private Button buttonID;

    @FXML
    private TextField volume;

    @FXML
    private TextField ambientTemperature;

    @FXML
    private TextField result;

    @FXML
    private Label labelID;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        clickButton();
    }

    private void clickButton(){
        buttonID.setOnMouseClicked(s ->{
            double finalResult= Calc.getResult(ambientTemperature.getText(),volume.getText());

            if(finalResult<5){
                labelID.setText("Stygnięcie odbywa się powoli");
            }

            if(finalResult>=5 && finalResult<10){
                labelID.setText("Stygnięcie przebiega ze średnim tempem");
            }

            if(finalResult>=10){
                labelID.setText("Stygnięcie odbywa się bardzo szybko");
            }
            result.setText(String.valueOf(finalResult));
        });
    }
}
