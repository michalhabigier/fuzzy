package calculation;

import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.rule.Rule;
import net.sourceforge.jFuzzyLogic.FunctionBlock;

public class Calc {

    public static double getResult(String ambientTemperature, String volume) {
        double result = 0.0;
        String fileName = "./src/main/resources/tipper.fcl";
        FIS fis = FIS.load(fileName, true);

        if (fis == null) {
            System.err.println("Can't load file: '" + fileName + "'");

        }
        FunctionBlock functionBlock=new FunctionBlock(fis);

        if (fis != null) {
            fis.setVariable("ambientTemperature", Double.parseDouble(ambientTemperature));
            fis.setVariable("volume", Double.parseDouble(volume));
            fis.evaluate();
            System.out.println("Output value:" + fis.getVariable("cooldown").getValue()); // Show output variable
            result = fis.getVariable("cooldown").getValue();
            for (Rule r : fis.getFunctionBlock("tipper").getFuzzyRuleBlock("No1").getRules())
                System.out.println(r);
        }

        return result;
    }
}