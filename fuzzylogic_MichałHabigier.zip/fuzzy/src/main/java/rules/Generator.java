package rules;

import java.util.Arrays;
import java.util.List;

public class Generator {

    public static void main(String[] args) {
        List<String> ambientTemperatures = Arrays.asList("small", "medium", "high");
        List<String> volumes = Arrays.asList("small", "medium", "high", "veryHigh");
        int counter = 0;

        for (String s : ambientTemperatures) {
            for (String s1 : volumes) {

                System.out.println("RULE " + ++counter + ": IF ( ambientTemperature IS "+ s + " ) AND ( volume IS " + s1 +" ) THEN cooldown IS ");
            }
        }
    }
}